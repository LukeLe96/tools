Run: chmod +x consul-manager-linux && ./consul-manager-linux
